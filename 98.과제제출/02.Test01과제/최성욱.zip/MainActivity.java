package com.example.test01_layout;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    ImageView imgv1, imgv2, imgv3, imgv4, imgv5, imgv6;
    Button btn1, btn2;
    int index = 1;
    int click = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn1 = findViewById(R.id.bnt1);
        btn2 = findViewById(R.id.bnt2);
        imgv1 = findViewById(R.id.imgv1);
        imgv2 = findViewById(R.id.imgv2);
        imgv3 = findViewById(R.id.imgv3);
        imgv4 = findViewById(R.id.imgv4);
        imgv5 = findViewById(R.id.imgv5);
        imgv6 = findViewById(R.id.imgv6);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                click = 1;
                if(index ==3){
                    index = 1;
                } else {
                    index++;
                }
                changeImg();
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                click = 0;
                if(index ==3){
                    index = 1;
                } else {
                    index++;
                }
                changeImg();
            }
        });
    }
    public void changeImg(){
        imgv1.setVisibility(View.GONE);
        imgv2.setVisibility(View.GONE);
        imgv3.setVisibility(View.GONE);
        imgv4.setVisibility(View.GONE);
        imgv5.setVisibility(View.GONE);
        imgv6.setVisibility(View.GONE);
        if(click ==1 ){
            if(index == 1){
                imgv1.setVisibility(View.VISIBLE);
            } else if(index == 2){
                imgv2.setVisibility(View.VISIBLE);
            } else if(index == 3){
                imgv3.setVisibility(View.VISIBLE);
            }
        } else if(click == 0){
            if(index == 1){
                imgv4.setVisibility(View.VISIBLE);
            } else if(index == 2){
                imgv5.setVisibility(View.VISIBLE);
            } else if(index == 3){
                imgv6.setVisibility(View.VISIBLE);
            }
        }
    }
}